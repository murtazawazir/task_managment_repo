from odoo import fields,models


class CollectionSlab(models.Model):
    _name = 'collection.slab'

    collection_id = fields.Many2one('sale.policy')
    name = fields.Char(string='Name')

